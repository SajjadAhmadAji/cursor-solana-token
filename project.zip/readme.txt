echo "# cursor-solana-token" >> README.md
git init
git add README.md
git commit -m "first commit"
git branch -M main
git remote add origin https://github.com/SajjadAhmadAji/cursor-solana-token.git
git push -u origin main
